import 'mobx-react-lite/batchingForReactDom'
import GetStore from "./GetStore";

export default {
    GetStore,
}
